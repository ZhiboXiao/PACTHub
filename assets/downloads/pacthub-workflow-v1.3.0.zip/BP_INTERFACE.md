# BP integration interface

The public package supplies data preparation, geometry, FOV/sound-speed selection orchestration and MB reconstruction. **It contains no BP reconstruction core, in either Python or CUDA, and no bundled literature-based BP implementation.**

Use the existing `PAdata`, `sample_metadata.json` and `reconstruction_parameters.json` contract. A local BP implementation is connected as a Python callable; acquisition parameters continue to come from the two JSON files.

```python
from pa_pipeline.bp_interface import set_bp_backend
from pa_pipeline.workflow import run
from my_local_backend import reconstruct

set_bp_backend(reconstruct)
run('SAMPLE_DIR', 'runs/sample', methods=('bp',), backend='cpu')
```

The callback signature is:

```text
reconstruct(data, sensors, cfg, backend='cuda', speed=None,
            volume_sink=None, normals=None) -> (mip_yx, [axis_x, axis_y, axis_z])
```

- `data`: prepared real signal `[selected frame × channel, time]`.
- `sensors`: matching `[selected frame × channel, 3]` coordinates in mm.
- `cfg`: validated parameters, including physical grid, signal clock, sound speed and projection support.
- `normals`: transformed physical receive directions when registration supplies them.
- `speed`: optional sound-speed sweep override in m/s; otherwise use the JSON speed.
- `volume_sink`: when supplied, fill the provided float32 `[z,y,x]` array.
- Return the numerical XY-MIP and three physical coordinate axes in mm.

BP, automatic FOV and sound-speed selection stop before reading RF when no callback has been registered. Data inspection and parameter preparation remain available. MB with recorded FOV and sound speed runs independently; its optional `BP_matched` comparison is skipped when no BP callback is available.

The flow is summarized in [PIPELINE_PSEUDOCODE.md](PIPELINE_PSEUDOCODE.md). Image and video assets on the website retain their original provenance.

## Keep the existing CLI

Save the following as a local `local_runner.py` alongside your installed workflow:

```python
from pa_pipeline.bp_interface import set_bp_backend
from pa_pipeline.cli import main
from my_local_backend import reconstruct

set_bp_backend(reconstruct)
main()
```

Then use the existing commands with `python local_runner.py run ...`. This runner connects your local code; it does not implement BP. `inspect` and `configure` can still use `python reconstruct.py` directly.
