"""External BP integration contract. This module contains no BP algorithm."""

_implementation = None


def set_bp_backend(function):
    """Register a local callable with the documented reconstruct signature."""
    global _implementation
    if function is not None and not callable(function):
        raise TypeError('BP backend must be callable or None')
    _implementation = function


def bp_available():
    return _implementation is not None


def require_bp_backend():
    if not bp_available():
        raise RuntimeError('BP core is not distributed. Register a local implementation '
                           'with pa_pipeline.bp_interface.set_bp_backend before BP, '
                           'automatic FOV or sound-speed selection. See BP_INTERFACE.md.')


def reconstruct(data, sensors, cfg, backend='cuda', speed=None,
                volume_sink=None, normals=None):
    require_bp_backend()
    return _implementation(data, sensors, cfg, backend=backend, speed=speed,
                           volume_sink=volume_sink, normals=normals)
