# PACTHub reconstruction pipeline

Reconstruct the standardized PA data using back-projection (BP) and the supplied V3 model-based (MB) solver. Field-of-view selection and sound-speed selection share the same input configuration and physical coordinates.


**BP core distribution:** the public package keeps the complete FOV, sound-speed selection, preprocessing, geometry and MB implementations. Only the BP numerical core is excluded. Connect a local BP using [BP_INTERFACE.md](BP_INTERFACE.md); the workflow pseudocode is in [PIPELINE_PSEUDOCODE.md](PIPELINE_PSEUDOCODE.md).

[中文说明与完整参数表](README_CN.md) · [Website guide](https://pacthub.net/docs/algorithm-guide.html)

```text
PAdata + sample_metadata.json + reconstruction_parameters.json
    → validate → select frames and preprocess
    → select FOV → select sound speed
    → BP / MB → numerical 3D volumes, MIPs and effective parameters
```

## Input contract

Use the two JSON files delivered with each acquisition:

- `sample_metadata.json`: acquisition ID, FTC storage axes, array shape, data type and frame count.
- `reconstruction_parameters.json`: data paths, signal processing, frame indices, geometry, grid, sound speed and reconstruction settings. The published `1.0.0` and registered `1.0.0+starnet-rigid-v3` formats are supported.

The PA file is an HDF5 MAT/H5 array named `pa_data`, stored as `[frame, time, channel]`, with 1024 channels. Paths resolve relative to the parameter JSON. Sampling, signal scaling and channel conventions follow the recorded standardization.

Existing profiles reference a detector-coordinate MAT through `inputs.detector_file`. `configure --embed-detectors` copies those coordinates into `defaults.geometry.detector_xyz_mm`; subsequent reconstruction then needs only the PA file and the two JSON files. MB options are stored in `defaults.mb` in the same JSON.

## Install

Use Python 3.10 or newer. From this directory, install the base package:

```sh
python -m pip install .
```

A connected CUDA BP may require CuPy matching the installed CUDA runtime. MB requires a CUDA-compatible PyTorch installation, Ninja and the CUDA compiler (`nvcc`). For a CUDA 12 environment, install `cupy-cuda12x`; install the PyTorch build appropriate to your GPU environment. BP backend dependencies are determined by your local implementation.

## Run

`SAMPLE_DIR` is a downloaded acquisition directory containing its two JSON files. First check the input, then generate a working profile and reconstruct:

```sh
python reconstruct.py inspect "SAMPLE_DIR"

python reconstruct.py configure "SAMPLE_DIR" --out profiles/sample --embed-detectors --with-mb --auto-fov --auto-speed

python local_runner.py run profiles/sample --methods bp mb --out runs/sample --device 0
```

`local_runner.py` registers your local BP and invokes the unchanged CLI, as shown in BP_INTERFACE.md. For MB without BP, use `python reconstruct.py run profiles/sample --methods mb --out runs/MB --device 0` with automatic FOV/speed disabled.

Omit `--auto-fov --auto-speed` to retain the recorded FOV and sound speed. `configure` creates a new pair of JSON files and retains the original PA data paths. Numerical settings are edited in that profile; command-line options choose paths, methods and the compute device. The installed command `pact-reconstruct` exposes the same interface.

Automatic FOV uses a large-FOV BP MIP to estimate the XY centre and long axis. Sound-speed selection evaluates the recorded candidate list with fixed frames, geometry and preprocessing. Candidate scores and masks are saved. Ambiguous candidates retain the recorded settings; selected values are saved in the output profile.

## Outputs

| Directory | Result |
|---|---|
| `BP/` | Recorded preprocessing and connected local BP |
| `MB/` | V3 finite-disk forward/adjoint model and nonnegative iterative reconstruction |
| `BP_matched/` | Connected local BP using the identical MB input; skipped if no BP is connected |
| `profile/` | The two effective JSON files, ready to replay the selected parameters |
| `fov_detection/`, `speed_selection/` | Selection images, numerical scores and decisions when enabled |

Each reconstruction includes `mip.npz`, preview PNGs and execution records. With `defaults.output.save_volume=true`, `volume.h5` stores the float32 volume in **ZYX** order and physical axes in **mm**. MIP arrays use **YX** order. Preview normalization is separate from numerical output. BP and MB retain their respective operator-dependent amplitude units.

## Examples and verification

`examples/legacy_template` demonstrates the existing schema with a separate coordinate MAT. `examples/embedded_two_json` contains the same acquisition with embedded detector coordinates and MB settings. Both refer to acquisition `20241213_151351`: place its PA file at the example's recorded path or edit the paths. For another acquisition, start from that acquisition's own JSON pair.

```sh
python -m unittest discover -s tests -v
```

The 15 local tests cover data contracts, geometry, MB input preparation, missing-backend handling and callback replay. Routing tests use constant-output stubs; no BP core is included in the tests. Details are in `validation_report.json`.

The published metadata audit covers 1,469 acquisitions: 1,327 parameter records pass the interface checks and 142 retain their recorded unresolved status. This entry point reconstructs individual acquisition positions. Full-scan fusion requires explicit inter-position trajectories and fusion settings. Current reconstruction profiles use a single effective sound speed.

## Website and code maintenance

The repository root serves the static website. This directory contains the independently installable Python/CUDA package. GitHub Pages serves the code download and guides; reconstruction runs on a local machine or GPU server. RF datasets remain available through the website's Google Drive link.

After changing code, regenerate the small website download from the repository root:

```sh
python scripts/package_reconstruction.py
python scripts/package_reconstruction.py --check
```

The package script includes workflow source, the MB CUDA kernel, documentation, examples and interface tests. It rejects BP numerical cores. It records source hashes and excludes generated reconstructions, environments and RF data. Run the CPU tests and package check locally before uploading changes.
